var modal = document.getElementById('mymodal');
var modal1 = document.getElementById('mymodal1');
var modal2 = document.getElementById('mymodal2');
var modal3 = document.getElementById('mymodal3');
var modal4 = document.getElementById('mymodal4');
var modal5 = document.getElementById('mymodal5');
var mybtn = document.getElementById("mybtn");
var mybtn1 = document.getElementById("mybtn1");
var mybtn2 = document.getElementById('mybtn2');
var mybtn3 = document.getElementById('mybtn3');
var mybtn4 = document.getElementById('mybtn4');
var mybtn5 = document.getElementById('mybtn5');
var closebtn = document.getElementsByClassName("close")[0];
var closebtn1 = document.getElementsByClassName("close1")[0];
var closebtn2 = document.getElementsByClassName("close2")[0];
var closebtn3 = document.getElementsByClassName("close3")[0];
var closebtn4 = document.getElementsByClassName("close4")[0];
var closebtn5 = document.getElementsByClassName("close5")[0];
mybtn.addEventListener('click',openmodal);
mybtn1.addEventListener('click',openmodal1);
mybtn2.addEventListener('click',openmodal2);
mybtn3.addEventListener('click',openmodal3);
mybtn4.addEventListener('click',openmodal4);
mybtn5.addEventListener('click',openmodal5);
closebtn.addEventListener('click',closemodal);
closebtn1.addEventListener('click',closemodal1);
closebtn2.addEventListener('click',closemodal2);
closebtn3.addEventListener('click',closemodal3);
closebtn4.addEventListener('click',closemodal4);
closebtn5.addEventListener('click',closemodal5);
window.addEventListener('click',clickoutside);
function openmodal(){
    modal.style.display = 'block';
}
function openmodal1(){
    modal1.style.display = 'block';
}
function openmodal2(){
    modal2.style.display = 'block';
}
function openmodal3(){
    modal3.style.display = 'block';
}
function openmodal4(){
    modal4.style.display = 'block';
}
function openmodal5(){
    modal5.style.display = 'block';
}
function closemodal(){
    modal.style.display = 'none';
}
function closemodal1(){
    modal1.style.display = 'none';
}
function closemodal2(){
    modal2.style.display = 'none';
}
function closemodal3(){
    modal3.style.display = 'none';
}
function closemodal4(){
    modal4.style.display = 'none';
}
function closemodal5(){
    modal5.style.display = 'none';
}
function clickoutside(e){
    if(e.target == modal){
        modal.style.display = 'none';
    }
    if(e.target == modal1){
        modal1.style.display = 'none';
    }
    if(e.target == modal2){
        modal2.style.display = 'none';
    }
    if(e.target == modal3){
        modal3.style.display = 'none';
    }
    if(e.target == modal4){
        modal4.style.display = 'none';
    }
    if(e.target == modal5){
        modal5.style.display = 'none';
    }
}
